﻿Module Module1
    '----------------------------------------------------------------------------
    'Program Info
    '----------------------------------------------------------------------------
    'Program:Temperature Converter
    'Date:2023-09-20
    'Author:Xiangyu Feng
    'Operation: This program does what..... ?
    '-----------------------------------------------------------------------------
    'Change Log
    '-----------------------------------------------------------------------------
    'Date      Programmer     Change
    '-----------------------------------------------------------------------------
    'None
    '-----------------------------------------------------------------------------
    Sub Main()

        'Define Variables
        Dim celsiusTem As Single
        Dim FahrenheitTem As Single

        'Prompt user type a celsius temperature
        Console.WriteLine("Please type a celsius temperature, then press Enter: ")

        'User input variable from keyboard
        celsiusTem = Console.ReadLine()

        'Calculate the convert process
        FahrenheitTem = celsiusTem * (9 / 5) + 32

        'Output the result
        Console.WriteLine($"Celsius temperature {celsiusTem} ℃ is equal to {FahrenheitTem} °F.")

        'End
        Threading.Thread.Sleep(500)
        Console.WriteLine("Please press Enter to End the calculation.")
        Console.ReadKey()

    End Sub

End Module
