﻿'----------------------------------------------------------------------------
'Program Info
'----------------------------------------------------------------------------
'Program:Case Statements
'Date:01-11-2023
'Author:Xiangyu Feng
'Operation: Using Case statements, create a console application that prompts
'the user to select one of 10 different games. Each game will have either 1 2
'or 4 players. Once the Game has been selected, the player name(s) should be
'prompted for. Games 1, 3 And 5 will be one player games. Games 2, 4 And 6 are
'two Player Games, all remaining games are four player games. Report to the
'console the Selected Game, how many players the game has And Each player's
'Name.
'-----------------------------------------------------------------------------
'Change Log
'-----------------------------------------------------------------------------
'Date                   Programmer                   Change
'-----------------------------------------------------------------------------
'01-11-2023             Xiangyu Feng                 First Built
'03-11-2023             Xiangyu Feng                 Fixed Possible Crash
'                                                    When Typing letter by using
'                                                    Str instead of Int16 for
'                                                    variable number.
Module Module1

    Sub Main()
        Dim number As String
        Dim P1 As String
        Dim P2 As String
        Dim P3 As String
        Dim P4 As String
        Dim Game1 As String
        Dim Game2 As String
        Dim Game3 As String
        Dim Game4 As String
        Dim Game5 As String
        Dim Game6 As String
        Dim Game7 As String
        Dim Game8 As String
        Dim Game9 As String
        Dim Game10 As String

        Game1 = "Donkey Kong"
        Game2 = "Street Fighter"
        Game3 = "World of Warcraft"
        Game4 = "Plants vs Zombies"
        Game5 = "Final Fantasy"
        Game6 = "Super Mario"
        Game7 = "Contra"
        Game8 = "Star Craft"
        Game9 = "Red Alert"
        Game10 = "Conter Strike"

        'Show Game List
        Console.WriteLine("Select a Game to Play:")
        Console.WriteLine("1." & Game1)
        Console.WriteLine("2." & Game2)
        Console.WriteLine("3." & Game3)
        Console.WriteLine("4." & Game4)
        Console.WriteLine("5." & Game5)
        Console.WriteLine("6." & Game6)
        Console.WriteLine("7." & Game7)
        Console.WriteLine("8." & Game8)
        Console.WriteLine("9." & Game9)
        Console.WriteLine("10." & Game10)

        'Prompt User Choose a Game
        number = Console.ReadLine()
        Console.WriteLine()

        'Which Game Chosen
        Select Case number
            'Prompt user Type player's name
            'only 1 player for game 1, 3, 5
            Case 1, 3, 5
                Console.WriteLine("Enter Player 1 Name:")
                P1 = Console.ReadLine()
                Console.WriteLine()
                'Print Game Name and Player Name for 1 Player Game
                Select Case number
                    Case 1
                        Console.WriteLine($"Game Selected: {Game1}")
                    Case 3
                        Console.WriteLine($"Game Selected: {Game3}")
                    Case 5
                        Console.WriteLine($"Game Selected: {Game5}")
                End Select
                Console.WriteLine("Number of Players: 1")
                Console.WriteLine()
                print()
                Console.WriteLine($"Player 1: {P1}")
                Console.WriteLine("Press Any Key to Start Game")

            'Prompt user Type players's names
            '2 players for game 2, 4, 6
            Case 2, 4, 6
                Console.WriteLine("Enter Player 1 Name:")
                P1 = Console.ReadLine()
                Console.WriteLine("Enter Player 2 Name:")
                P2 = Console.ReadLine()
                Console.WriteLine()
                'Print Game Name and Player Name for 2 Players Game
                Select Case number
                    Case 2
                        Console.WriteLine($"Game Selected: {Game2}")
                    Case 4
                        Console.WriteLine($"Game Selected: {Game4}")
                    Case 6
                        Console.WriteLine($"Game Selected: {Game6}")
                End Select
                Console.WriteLine("Number of Players: 2")
                Console.WriteLine()
                print()
                Console.WriteLine($"Player 1: {P1}")
                Console.WriteLine($"Player 1: {P2}")
                Console.WriteLine("Press Any Key to Start Game")

                'Prompt user Type players's names
                '4 players for else game (7, 8, 9, 10)
            Case 7, 8, 9, 10
                Console.WriteLine("Enter Player 1 Name:")
                P1 = Console.ReadLine()
                Console.WriteLine("Enter Player 2 Name:")
                P2 = Console.ReadLine()
                Console.WriteLine("Enter Player 3 Name:")
                P3 = Console.ReadLine()
                Console.WriteLine("Enter Player 4 Name:")
                P4 = Console.ReadLine()
                Console.WriteLine()
                'Print Game Name and Player Name for else 4 Players Game
                Select Case number
                    Case 7
                        Console.WriteLine($"Game Selected: {Game7}")
                    Case 8
                        Console.WriteLine($"Game Selected: {Game8}")
                    Case 9
                        Console.WriteLine($"Game Selected: {Game9}")
                    Case 10
                        Console.WriteLine($"Game Selected: {Game10}")
                End Select
                Console.WriteLine("Number of Players: 4")
                Console.WriteLine()
                print()
                Console.WriteLine($"Player 1: {P1}")
                Console.WriteLine($"Player 1: {P2}")
                Console.WriteLine($"Player 1: {P3}")
                Console.WriteLine($"Player 1: {P4}")
                Console.WriteLine("Press Any Key to Start Game")
            Case Else
                'If Number is Not Between 0 - 10
                Console.WriteLine("Illegal Input! Please Type an integer number between 1 - 10 After Reboot.")
                Console.WriteLine("Press Any Key to End Game Selector.")
        End Select

        Console.ReadKey()

    End Sub
    Sub print()
        'Print Player List Header
        Console.WriteLine("Player(s)")
        Console.WriteLine("--------")
    End Sub

End Module
