﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblCalculatorTittle = New System.Windows.Forms.Label()
        Me.lblNumber1 = New System.Windows.Forms.Label()
        Me.lblNumber2 = New System.Windows.Forms.Label()
        Me.lblNmuber3 = New System.Windows.Forms.Label()
        Me.lblAverageTittle = New System.Windows.Forms.Label()
        Me.lblAverageValue = New System.Windows.Forms.Label()
        Me.txtNum1 = New System.Windows.Forms.TextBox()
        Me.txtNum2 = New System.Windows.Forms.TextBox()
        Me.txtNum3 = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblCalculatorTittle
        '
        Me.lblCalculatorTittle.AutoSize = True
        Me.lblCalculatorTittle.Font = New System.Drawing.Font("SimSun", 16.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.lblCalculatorTittle.Location = New System.Drawing.Point(29, 26)
        Me.lblCalculatorTittle.Name = "lblCalculatorTittle"
        Me.lblCalculatorTittle.Size = New System.Drawing.Size(298, 22)
        Me.lblCalculatorTittle.TabIndex = 0
        Me.lblCalculatorTittle.Text = "Grade Average Calculator"
        '
        'lblNumber1
        '
        Me.lblNumber1.AutoSize = True
        Me.lblNumber1.Location = New System.Drawing.Point(29, 104)
        Me.lblNumber1.Name = "lblNumber1"
        Me.lblNumber1.Size = New System.Drawing.Size(53, 12)
        Me.lblNumber1.TabIndex = 1
        Me.lblNumber1.Text = "Number 1"
        '
        'lblNumber2
        '
        Me.lblNumber2.AutoSize = True
        Me.lblNumber2.Location = New System.Drawing.Point(29, 162)
        Me.lblNumber2.Name = "lblNumber2"
        Me.lblNumber2.Size = New System.Drawing.Size(53, 12)
        Me.lblNumber2.TabIndex = 2
        Me.lblNumber2.Text = "Number 2"
        '
        'lblNmuber3
        '
        Me.lblNmuber3.AutoSize = True
        Me.lblNmuber3.Location = New System.Drawing.Point(29, 223)
        Me.lblNmuber3.Name = "lblNmuber3"
        Me.lblNmuber3.Size = New System.Drawing.Size(53, 12)
        Me.lblNmuber3.TabIndex = 3
        Me.lblNmuber3.Text = "Number 3"
        '
        'lblAverageTittle
        '
        Me.lblAverageTittle.AutoSize = True
        Me.lblAverageTittle.Location = New System.Drawing.Point(29, 323)
        Me.lblAverageTittle.Name = "lblAverageTittle"
        Me.lblAverageTittle.Size = New System.Drawing.Size(71, 12)
        Me.lblAverageTittle.TabIndex = 4
        Me.lblAverageTittle.Text = "The Average"
        '
        'lblAverageValue
        '
        Me.lblAverageValue.AutoSize = True
        Me.lblAverageValue.Location = New System.Drawing.Point(29, 345)
        Me.lblAverageValue.Name = "lblAverageValue"
        Me.lblAverageValue.Size = New System.Drawing.Size(71, 12)
        Me.lblAverageValue.TabIndex = 5
        Me.lblAverageValue.Text = "The Average"
        '
        'txtNum1
        '
        Me.txtNum1.Location = New System.Drawing.Point(31, 120)
        Me.txtNum1.Name = "txtNum1"
        Me.txtNum1.Size = New System.Drawing.Size(100, 21)
        Me.txtNum1.TabIndex = 6
        '
        'txtNum2
        '
        Me.txtNum2.Location = New System.Drawing.Point(31, 177)
        Me.txtNum2.Name = "txtNum2"
        Me.txtNum2.Size = New System.Drawing.Size(100, 21)
        Me.txtNum2.TabIndex = 7
        '
        'txtNum3
        '
        Me.txtNum3.Location = New System.Drawing.Point(31, 238)
        Me.txtNum3.Name = "txtNum3"
        Me.txtNum3.Size = New System.Drawing.Size(100, 21)
        Me.txtNum3.TabIndex = 8
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(31, 282)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(87, 23)
        Me.btnCalculate.TabIndex = 9
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(159, 282)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(87, 23)
        Me.btnClear.TabIndex = 10
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(368, 397)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtNum3)
        Me.Controls.Add(Me.txtNum2)
        Me.Controls.Add(Me.txtNum1)
        Me.Controls.Add(Me.lblAverageValue)
        Me.Controls.Add(Me.lblAverageTittle)
        Me.Controls.Add(Me.lblNmuber3)
        Me.Controls.Add(Me.lblNumber2)
        Me.Controls.Add(Me.lblNumber1)
        Me.Controls.Add(Me.lblCalculatorTittle)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCalculatorTittle As Label
    Friend WithEvents lblNumber1 As Label
    Friend WithEvents lblNumber2 As Label
    Friend WithEvents lblNmuber3 As Label
    Friend WithEvents lblAverageTittle As Label
    Friend WithEvents lblAverageValue As Label
    Friend WithEvents txtNum1 As TextBox
    Friend WithEvents txtNum2 As TextBox
    Friend WithEvents txtNum3 As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
End Class
