﻿'----------------------------------------------------------------------------
'Program Info
'----------------------------------------------------------------------------
'Program:Average Calculator
'Date:22/10/2023
'Author:Xiangyu Feng
'Operation: Create a GUI version of the Average Calculator program that will
'be used as a grade average calculator For a 3-grade course.
'
'Requirements:
'- Use if statements to prevent user input errors from occurring when
'clicking the Calculate button.
'- If the value falls under one of the conditions above, use the messagebox
'function to display a message to the user to indicate the error condition.
'- Use a label control to display the result of the calculation. 
'60% and above, change the text to green
'Below 60%, set the color to red
'- Include a clear button that will reset the controls back to their default
'state.
'
'-----------------------------------------------------------------------------
'Change Log
'-----------------------------------------------------------------------------
'Date                    Programmer                     Change
'-----------------------------------------------------------------------------
'22/10/2023              Xiangyu Feng                   First Release
Public Class Form1
    Dim num_1 As Double
    Dim num_2 As Double
    Dim num_3 As Double
    Dim result As Int16
    Private Sub btCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Check if the input number 1 is a number.
        If IsNumeric(txtNum1.Text) = False Then
            MsgBox("Please type a number in the Number 1 textbox.")
            txtNum1.Focus()

            'Check if input number 1 is not Less than 0 and not greater than 100.
        ElseIf (txtNum1.Text < 0) Or (txtNum1.Text > 100) Then
            MsgBox("Please type a value not Less than 0 and not greater than 100 in number 1.")
            txtNum1.Focus()

            'Check if the input number 2 is a number.
        ElseIf IsNumeric(txtNum2.Text) = False Then
            MsgBox("Please type a number in the Number 2 textbox.")
            txtNum2.Focus()

            'Check if input number 2 is not Less than 0 and not greater than 100.
        ElseIf (txtNum2.Text < 0) Or (txtNum2.Text > 100) Then
            MsgBox("Please type a value not Less than 0 and not greater than 100 in number 2.")
            txtNum2.Focus()

            'Check if the input number 3 is a number.
        ElseIf IsNumeric(txtNum3.text) = False Then
            MsgBox("Please type a number in the Number 3 textbox.")
            txtNum3.Focus()

            'Check if input number 3 is not Less than 0 and not greater than 100.
        ElseIf (txtNum3.Text < 0) Or (txtNum3.Text > 100) Then
            MsgBox("Please type a value not Less than 0 and not greater than 100 in number 3.")
            txtNum3.Focus()
        Else
            'Convert input value to number format.
            'https://learn.microsoft.com/en-us/dotnet/visual-basic/language-reference/functions/type-conversion-functions
            num_1 = CDbl(txtNum1.Text)
            num_2 = CDbl(txtNum2.Text)
            num_3 = CDbl(txtNum3.Text)

            'Calculate average with three numbers.
            result = (num_1 + num_2 + num_3) / 3

            'Print red result if value < 60.
            If result < 60 Then
                lblAverageValue.Text = result
                lblAverageValue.ForeColor = Color.Red
                'Print green result if valur >= 60
            Else
                lblAverageValue.Text = result
                lblAverageValue.ForeColor = Color.Green
            End If
        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear all textboxes
        txtNum1.Clear()
        txtNum2.Clear()
        txtNum3.Clear()
        'Dim a As Control
        'For Each a In Me.Controls
        '    If TypeOf a Is TextBox Then
        '        a.Text = Nothing
        '    End If
        'Next
        'https://stackoverflow.com/questions/17906065/clearing-many-textbox-controls-in-vb-net-at-once
    End Sub
End Class
