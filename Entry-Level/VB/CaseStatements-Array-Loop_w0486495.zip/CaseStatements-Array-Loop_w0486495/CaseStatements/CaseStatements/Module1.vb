﻿'----------------------------------------------------------------------------
'Program Info
'----------------------------------------------------------------------------
'Program:Case Statements
'Date:01-11-2023
'Author:Xiangyu Feng
'Operation: Using Case statements, create a console application that prompts
'the user to select one of 10 different games. Each game will have either 1 2
'or 4 players. Once the Game has been selected, the player name(s) should be
'prompted for. Games 1, 3 And 5 will be one player games. Games 2, 4 And 6 are
'two Player Games, all remaining games are four player games. Report to the
'console the Selected Game, how many players the game has And Each player's
'Name.
'-----------------------------------------------------------------------------
'Change Log
'-----------------------------------------------------------------------------
'Date            Programmer        Change
'-----------------------------------------------------------------------------
'01-11-2023      Xiangyu Feng      First Built
'03-11-2023      Xiangyu Feng      Fixed Possible Crash
'                                  When Typing letter by using
'                                  Str instead of Int16 for
'                                  variable dbl_Num.
'28-11-2023      Xiangyu Feng      Use Array & Loop to Capture & Print 
'29-11-2023      Xiangyu Feng      Fixed Possible Crush from Unexpected Input
Imports System.Net.Security
Imports System.Reflection
Imports System.Security.Cryptography.X509Certificates

Module Module1
    Dim str_input As String
    Dim dbl_Num As Double
    Dim arr_GameList() As String = {"Donkey Kong", "Street Fighter", "World of Warcraft", "Plants vs Zombies", "Final Fantasy", "Super Mario", "Contra", "Star Craft", "Red Alert", "Conter Strike"}
    Dim arr_PlayerList(3) As String
    Dim byte_Counter As Int16
    Dim bool_Counter As Boolean = True
    Dim bool_Counter_2 As Boolean = True
    Dim str_selectAga As String
    Dim int_PlayerNum As Int16

    Sub Main()
        ListAndAsk()
        ProcessCal()
    End Sub


    Sub ListAndAsk()
        'List All the Games on Console
        For Counter = 0 To arr_GameList.Count - 1
            Console.WriteLine($"{Counter + 1}.{arr_GameList(Counter)}")
        Next
        Console.WriteLine()

        'Ask User to choose a Game
        Console.WriteLine("Select a Game to Play:")
        str_input = Console.ReadLine()
    End Sub

    Sub ProcessCal()
        Do While bool_Counter = True
            'Which Game has been Chosen?
            'Validate Input from User
            If IsNumeric(str_input) = False Then
                'Request User Validate Input.
                Console.WriteLine($"Illegal Input! Please Type an integer number between 1 - {arr_GameList.Count - 1} After Reboot.")
                Console.WriteLine("-------------------------------------------------------------------------")
                Console.WriteLine()
                ListAndAsk()
            Else
                'Convert inputdata from string to double 
                dbl_Num = CDbl(str_input)
                If dbl_Num > 0 And dbl_Num < 11 Then
                    Console.WriteLine($"Game Selected: {arr_GameList(dbl_Num - 1)}")
                    'Get the Number of Players
                    If dbl_Num = 1 Or dbl_Num = 3 Or dbl_Num = 5 Then
                        int_PlayerNum = 1
                    ElseIf dbl_Num = 2 Or dbl_Num = 4 Or dbl_Num = 6 Then
                        int_PlayerNum = 2
                    Else
                        int_PlayerNum = 4
                    End If

                    'Capture All Players' Names as Array
                    For byte_Counter = 0 To int_PlayerNum - 1

                        Console.WriteLine($"Enter Player {byte_Counter + 1}'s Name:")
                        arr_PlayerList(byte_Counter) = Console.ReadLine()
                    Next
                    'Reset the Counter 
                    byte_Counter = 0

                    'Print Game Name and All Players' Names for Game
                    Console.WriteLine($"Game Selected: {arr_GameList(dbl_Num - 1)}")
                    Console.WriteLine($"Number of Players: {int_PlayerNum}")
                    For byte_Counter = 0 To arr_PlayerList.Count - 1
                        Console.WriteLine($"Player {byte_Counter + 1}: {arr_PlayerList(byte_Counter)}")
                        If byte_Counter = int_PlayerNum - 1 Then
                            Exit For
                        End If
                    Next

                    'Ask If User Want To Select Again?
                    Do
                        Console.WriteLine("Do you want to select again?(Y/N)")
                        'Input Validate
                        str_selectAga = Console.ReadLine().ToUpper
                        'Yes, User Wants to Select Again!
                        If str_selectAga = "Y" Or str_selectAga = "YES" Then
                            Console.Clear()
                            ListAndAsk()
                            bool_Counter = True
                            bool_Counter_2 = False

                            'No, User Does Not Want to.
                        ElseIf str_selectAga = "N" Or str_selectAga = "NO" Then
                            Console.WriteLine("Press Any Key to End Game Selector.")
                            Console.ReadKey()
                            bool_Counter = False
                            bool_Counter_2 = False

                            'Invalid Input
                        Else
                            bool_Counter = True
                            Console.WriteLine("Invalid input, please select again.")
                            Continue Do
                        End If

                    Loop Until bool_Counter_2 = False
                ElseIf dbl_Num > 10 Or dbl_Num < 1 Then
                    Console.WriteLine($"Illegal Input! Please Type an integer number between 1 - {arr_GameList.Count - 1} After Reboot.")
                    Console.WriteLine("-------------------------------------------------------------------------")
                    Console.WriteLine()
                    ListAndAsk()
                End If
            End If
        Loop
    End Sub

End Module
