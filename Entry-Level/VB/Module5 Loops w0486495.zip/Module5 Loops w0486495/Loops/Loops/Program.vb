'----------------------------------------------------------------------------
'Program Info
'----------------------------------------------------------------------------
'Program:Loops
'Date:20-11-2023
'Author:Xiangyu Feng
'Operation: Use Loop to calculate sum, count and average.
'
'
'-----------------------------------------------------------------------------
'Change Log
'-----------------------------------------------------------------------------
'Date                 Programmer                Change
'-----------------------------------------------------------------------------
'20-11-2023           Xiangyu Feng              First Built

Imports System
Module Program

    Sub Main(args As String())
        Dim Int_Counter As Int16 = 0
        Dim Str_Input As String
        Dim db_number As Double
        Dim Sin_Sum As Single
        Dim Sin_Ave As Single
        Dim boolContinue As Boolean = True

        'Prompt user to type a number
        Console.WriteLine("Average Calculator press the = key to calculate when complete.")
        While boolContinue = True
            Console.WriteLine("Enter a number between 1 and 100 to be averaged")
            Str_Input = Console.ReadLine()

            'Use Str_Input As a boolean
            'Exit loop while user type a =
            If Str_Input = "=" Then
                boolContinue = False
                Exit While

                'If user type a number
            ElseIf IsNumeric(Str_Input) = False Then
                Console.WriteLine("That is not a Number...")
                Continue While

                'Use Str_Input As a number
            Else
                'Convert inputdata from string to double 
                db_number = CDbl(Str_Input)
                'If the number is between 0 and 100
                If db_number > 0 And db_number < 100 Then
                    Sin_Sum += db_number
                    Int_Counter += 1
                    Sin_Ave = Math.Round((Sin_Sum / Int_Counter), 2)

                    'If the number is not in the range
                ElseIf db_number < 0 Or db_number > 100 Then
                    Console.WriteLine("Number is out of range...")
                    Continue While
                End If
            End If
        End While
        Console.WriteLine("The results are...")
        Console.WriteLine($"The Sum is {Sin_Sum}")
        Console.WriteLine($"The Count is {Int_Counter}")
        Console.WriteLine($"The Average is {Sin_Ave}")
        Console.WriteLine("Press Any Key to exit...")
        Console.ReadKey()
    End Sub
End Module
