﻿Module Module1

    Sub Main()
        '----------------------------------------------------------------------------
        'Program Info
        '----------------------------------------------------------------------------
        'Program:Gas Guzzler
        'Date:2023-10-04
        'Author:Xiangyu Feng
        'Operation: Receive start kilometers and end kilometers, filled price ,liters.
        '           from users, then calculate process and output calculation result:

        '           1.Calculate travelled kilometers by using start odometer and end
        '           odometer,
        '
        '           2.Transfer travelled kilometers to miles, then output on console.
        '
        '           3.Transfer used liters to gallons and output on console.
        '
        '           4.Calculate mile per gallon and output on console.
        ' 
        '           5.Calculate cost per km and output on console.
        '
        '-----------------------------------------------------------------------------
        'Change Log
        '-----------------------------------------------------------------------------
        'Date                 Programmer               Change
        '-----------------------------------------------------------------------------
        '2023-10-04           Xiangyu Feng             v1.0 (First Release)

        'Define input and output variables
        Dim filled_Kms_start As UInteger
        Dim filled_Kms_end As UInteger
        Dim filled_Price As Decimal
        Dim filled_Liters As Single
        Dim travelled_Kms As UInteger
        Dim travelled_Miles As UInteger
        Dim used_Gallons As Single
        Dim miles_Per_gallon As Single
        Dim cost_Per_km As Decimal

        'Receive data filled by user
        Console.WriteLine("Please Enter Starting KMs:")
        filled_Kms_start = Console.ReadLine()

        Console.WriteLine("Please Enter End KMs:")
        filled_Kms_end = Console.ReadLine()

        Console.WriteLine("Please Enter Fill Up Price:")
        filled_Price = Console.ReadLine()

        Console.WriteLine("Please Enter Filled Liters:")
        filled_Liters = Console.ReadLine()

        'Calculate process and output calculation result
        'Calculate travelled kilometers by using start odometer and end odometer 
        travelled_Kms = filled_Kms_end - filled_Kms_start
        Console.WriteLine("KMs Travelled: " & travelled_Kms & " kms")

        'transfer travelled kilometers to miles
        travelled_Miles = travelled_Kms * 1.609344
        Console.WriteLine("Miles Travelled: " & travelled_Miles & " miles")
        '1 mile = 1.609344 kms. From https://www.google.com/

        'Transfer used liters to gallons and output on console.
        used_Gallons = Math.Round((filled_Liters * 3.785), 2)
        '1 gallon = 3.785 liters. From https://www.google.com/
        'Convert 2 decimal point https://stackoverflow.com/questions/16581901/how-to-convert-answer-into-two-decimal-point
        Console.WriteLine("Gallons Used: " & used_Gallons & " gallons")

        'Calculate mile per gallon and output on console.
        miles_Per_gallon = Math.Round((used_Gallons / travelled_Miles), 2)
        Console.WriteLine("Mile per Gallon: " & miles_Per_gallon)

        'Calculate cost per km and output on console.
        cost_Per_km = Math.Round((travelled_Kms / filled_Price), 2)
        Console.WriteLine("Cost Per Km: " & cost_Per_km)

        Console.ReadKey()

    End Sub

End Module
