﻿Imports System
'----------------------------------------------------------------------------
'Program Info
'----------------------------------------------------------------------------
'Program:Data Types Exercise 1
'Date:09/30/2023
'Author:Xiangyu Feng
'Operation: Write a visual basic console application and create an instance
'           of each of the variables with the datatype you selected for them.
'           Assign a value to the variable and print a message displaying
'           the value of each variable.
'
'
'-----------------------------------------------------------------------------
'Change Log
'-----------------------------------------------------------------------------
'Date           Programmer           Change
'-----------------------------------------------------------------------------
'09/30/2023     Xiangyu Feng         Establish
Module Program
    Sub Main(args As String())
        Dim age As Byte
        Dim birthday As Date
        Dim bankBalance As Decimal
        Dim scaleVal As SByte
        Dim startTime As Date
        Dim PI As Double
        Dim temp_Cel As Long
        Dim prompt As Boolean
        Dim odometer As UInteger
        Dim full_Name As String


        'Assign value to the variables
        'Print a message display the value of each variable
        age = 55
        Console.WriteLine($"Someone’s age is {age} years old.")

        birthday = #5/2/2022#
        Console.WriteLine($"Someone’s Birth Date is {birthday}.")

        bankBalance = 2000.32
        Console.WriteLine($"A bank account balance is ${bankBalance}.")

        scaleVal = 9
        Console.WriteLine($"A scale of 1 to 10 on how awesome programming is {scaleVal}.")

        startTime = #09-12-2023 12:30:00#
        Console.WriteLine($"The time programming class starts is {startTime}.")

        PI = Math.PI
        Console.WriteLine($"PI (π) is {PI}")
        'https://learn.microsoft.com/en-us/dotnet/api/system.math.pi?view=net-7.0

        temp_Cel = 50000
        Console.WriteLine($"A Celsius temperature, without decimal points, to represent modern temperatures on Earth is {temp_Cel}°C.")

        prompt = True
        If prompt = True Then
            Console.WriteLine("A prompt for a user to select Y for yes or N for no is yes.")
        Else
            Console.WriteLine("A prompt for a user to select Y for yes or N for no is no.")
        End If
        'https://learn.microsoft.com/en-us/dotnet/fsharp/language-reference/conditional-expressions-if-then-else
        'Decide by what is the pass parameter from DB.

        odometer = 200000
        Console.WriteLine($"An odometer that tracks kilometers for a car is {odometer}km.")

        full_Name = "Steve Nash"
        Console.WriteLine($"Someone’s Full Name is {full_Name}.")

        Console.WriteLine("Please type any keep to quit.")
        Console.ReadKey()

    End Sub
End Module
