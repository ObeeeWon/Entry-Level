﻿'----------------------------------------------------------------------------
'Program Info
'----------------------------------------------------------------------------
'Program:Average Calculator
'Date:22/10/2023
'Author:Xiangyu Feng
'Operation: Create a GUI version of the Average Calculator program that will
'be used as a grade average calculator For a 3-grade course.
'
'Requirements:
'- Use if statements to prevent user input errors from occurring when
'clicking the Calculate button.
'- If the value falls under one of the conditions above, use the messagebox
'function to display a message to the user to indicate the error condition.
'- Use a label control to display the Int_Result of the calculation. 
'60% and above, change the text to green
'Below 60%, set the color to red
'- Include a clear button that will reset the controls back to their default
'state.
'
'Date:23/11/2023
'Author:Xiangyu Feng
'Operation:
'
'-----------------------------------------------------------------------------
'Change Log
'-----------------------------------------------------------------------------
'Date                    Programmer                     Change
'-----------------------------------------------------------------------------
'22/10/2023              Xiangyu Feng                   First Release
'22/11/2023              Xiangyu Feng                   TextListBox Added
Imports System.Net.Security

Public Class Form1
    Dim Int_Result As Int16
    Dim Dbl_Sum As Double
    Dim Int_Counter As Byte
    Dim Int_CounterNested As Byte = 0
    Private Sub btAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        'Check if the input number 1 is a number.
        If IsNumeric(txtNum1.Text) = False Then
            MsgBox("Please type a number in the Grade textbox.")
            txtNum1.Focus()

            'Check if input number 1 is not Less than 0 and not greater than 100.
        ElseIf (txtNum1.Text < 0) Or (txtNum1.Text > 100) Then
            MsgBox("Please type a value not Less than 0 and not greater than 100 in Grade.")
            txtNum1.Focus()

            'Add a value to the text box list.
        Else
            lbxGrades.Items.Add(txtNum1.Text)
        End If
        txtNum1.Clear()
        txtNum1.Focus()
    End Sub



    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Convert input value to number format.
        'https://learn.microsoft.com/en-us/dotnet/visual-basic/language-reference/functions/type-conversion-functions
        'Calculate sum and average
        If lbxGrades.Items.Count > 0 Then
            For Int_Counter = 0 To lbxGrades.Items.Count - 1
                Dbl_Sum += lbxGrades.Items(Int_Counter)
                'Calculate average with all numbers.
                Int_Result = Dbl_Sum \ lbxGrades.Items.Count

                'Re-write logic: Must still be between 0 to 59
                If Int_Result < 60 Then
                    If lbxGrades.Items(Int_Counter) >= 90 And lbxGrades.Items(Int_Counter) <= 100 Then
                        Int_CounterNested += 1
                        'Print Re-write eligibility
                        'If the number of grades averaged is 3, one of the three grades entered 90-100
                        If Int_CounterNested = 1 And lbxGrades.Items.Count = 3 Then
                            lblRewriteVal.Text = "Re-write eligible"
                            lblRewriteVal.ForeColor = Color.Green

                            'If the number of grades averaged is 4 to 6, two of the grades entered 90-100
                        ElseIf Int_CounterNested = 2 And (lbxGrades.Items.Count > 3 And lbxGrades.Items.Count < 7) Then
                            lblRewriteVal.Text = "Re-write eligible"
                            lblRewriteVal.ForeColor = Color.Green

                            'If the number of grades averaged is over 6, three of the grades entered 90-100
                        ElseIf Int_CounterNested = 3 And lbxGrades.Items.Count > 6 Then
                            lblRewriteVal.Text = "Re-write eligible"
                            lblRewriteVal.ForeColor = Color.Green

                            'otherwise, it should be changed to “Rewrite not eligible”.
                        Else
                            lblRewriteVal.Text = "Re-write not eligible"
                            lblRewriteVal.ForeColor = Color.Red
                        End If
                    End If

                    'otherwise, it should be changed to “Rewrite not eligible”.
                Else
                    lblRewriteVal.Text = "Re-write not eligible"
                    lblRewriteVal.ForeColor = Color.Red
                End If
            Next
        End If

        'Print Average Result
        If Int_Result < 60 Then
            lblAverageValue.Text = Int_Result
            lblAverageValue.ForeColor = Color.Red

            'Print green Int_Result if valur >= 60
        Else
            lblAverageValue.Text = Int_Result
            lblAverageValue.ForeColor = Color.Green
        End If

        'Show the resualt and reset loop items
        lblAverageValue.Visible = True
        lblRewriteVal.Visible = True
        Dbl_Sum = 0
        Int_Counter = 0
        Int_CounterNested = 0

    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear all textboxes
        txtNum1.Clear()
        lbxGrades.Items.Clear()
        lblAverageValue.ResetText()
        lblRewriteVal.ResetText()

        'Dim a As Control
        'For Each a In Me.Controls
        '    If TypeOf a Is TextBox Then
        '        a.Text = Nothing
        '    End If
        'Next
        'https://stackoverflow.com/questions/17906065/clearing-many-textbox-controls-in-vb-net-at-once
    End Sub

End Class
