﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblCalculatorTittle = New System.Windows.Forms.Label()
        Me.lblGrade = New System.Windows.Forms.Label()
        Me.lblGradeList = New System.Windows.Forms.Label()
        Me.lblAverageTittle = New System.Windows.Forms.Label()
        Me.lblAverageValue = New System.Windows.Forms.Label()
        Me.txtNum1 = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lbxGrades = New System.Windows.Forms.ListBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lblReWrite = New System.Windows.Forms.Label()
        Me.lblRewriteVal = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblCalculatorTittle
        '
        Me.lblCalculatorTittle.AutoSize = True
        Me.lblCalculatorTittle.Font = New System.Drawing.Font("SimSun", 16.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.lblCalculatorTittle.Location = New System.Drawing.Point(29, 26)
        Me.lblCalculatorTittle.Name = "lblCalculatorTittle"
        Me.lblCalculatorTittle.Size = New System.Drawing.Size(298, 22)
        Me.lblCalculatorTittle.TabIndex = 0
        Me.lblCalculatorTittle.Text = "Grade Average Calculator"
        '
        'lblGrade
        '
        Me.lblGrade.AutoSize = True
        Me.lblGrade.Location = New System.Drawing.Point(29, 67)
        Me.lblGrade.Name = "lblGrade"
        Me.lblGrade.Size = New System.Drawing.Size(35, 12)
        Me.lblGrade.TabIndex = 1
        Me.lblGrade.Text = "Grade"
        '
        'lblGradeList
        '
        Me.lblGradeList.AutoSize = True
        Me.lblGradeList.Location = New System.Drawing.Point(31, 118)
        Me.lblGradeList.Name = "lblGradeList"
        Me.lblGradeList.Size = New System.Drawing.Size(65, 12)
        Me.lblGradeList.TabIndex = 2
        Me.lblGradeList.Text = "Grade List"
        '
        'lblAverageTittle
        '
        Me.lblAverageTittle.AutoSize = True
        Me.lblAverageTittle.Location = New System.Drawing.Point(29, 323)
        Me.lblAverageTittle.Name = "lblAverageTittle"
        Me.lblAverageTittle.Size = New System.Drawing.Size(71, 12)
        Me.lblAverageTittle.TabIndex = 4
        Me.lblAverageTittle.Text = "The Average"
        '
        'lblAverageValue
        '
        Me.lblAverageValue.AutoSize = True
        Me.lblAverageValue.Location = New System.Drawing.Point(29, 345)
        Me.lblAverageValue.Name = "lblAverageValue"
        Me.lblAverageValue.Size = New System.Drawing.Size(71, 12)
        Me.lblAverageValue.TabIndex = 5
        Me.lblAverageValue.Text = "The Average"
        Me.lblAverageValue.Visible = False
        '
        'txtNum1
        '
        Me.txtNum1.Location = New System.Drawing.Point(31, 83)
        Me.txtNum1.Name = "txtNum1"
        Me.txtNum1.Size = New System.Drawing.Size(100, 21)
        Me.txtNum1.TabIndex = 6
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(159, 79)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(87, 23)
        Me.btnAdd.TabIndex = 9
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(159, 282)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(87, 23)
        Me.btnClear.TabIndex = 10
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lbxGrades
        '
        Me.lbxGrades.FormattingEnabled = True
        Me.lbxGrades.ItemHeight = 12
        Me.lbxGrades.Location = New System.Drawing.Point(32, 139)
        Me.lbxGrades.Margin = New System.Windows.Forms.Padding(2)
        Me.lbxGrades.Name = "lbxGrades"
        Me.lbxGrades.Size = New System.Drawing.Size(99, 124)
        Me.lbxGrades.TabIndex = 11
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(33, 282)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(87, 23)
        Me.btnCalculate.TabIndex = 12
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'lblReWrite
        '
        Me.lblReWrite.AutoSize = True
        Me.lblReWrite.Location = New System.Drawing.Point(156, 323)
        Me.lblReWrite.Name = "lblReWrite"
        Me.lblReWrite.Size = New System.Drawing.Size(125, 12)
        Me.lblReWrite.TabIndex = 13
        Me.lblReWrite.Text = "Re-write Eligibility"
        '
        'lblRewriteVal
        '
        Me.lblRewriteVal.AutoSize = True
        Me.lblRewriteVal.Location = New System.Drawing.Point(158, 345)
        Me.lblRewriteVal.Name = "lblRewriteVal"
        Me.lblRewriteVal.Size = New System.Drawing.Size(89, 12)
        Me.lblRewriteVal.TabIndex = 14
        Me.lblRewriteVal.Text = "Re-write Value"
        Me.lblRewriteVal.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(368, 397)
        Me.Controls.Add(Me.lblRewriteVal)
        Me.Controls.Add(Me.lblReWrite)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lbxGrades)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.txtNum1)
        Me.Controls.Add(Me.lblAverageValue)
        Me.Controls.Add(Me.lblAverageTittle)
        Me.Controls.Add(Me.lblGradeList)
        Me.Controls.Add(Me.lblGrade)
        Me.Controls.Add(Me.lblCalculatorTittle)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCalculatorTittle As Label
    Friend WithEvents lblGrade As Label
    Friend WithEvents lblGradeList As Label
    Friend WithEvents lblAverageTittle As Label
    Friend WithEvents lblAverageValue As Label
    Friend WithEvents txtNum1 As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents lbxGrades As ListBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lblReWrite As Label
    Friend WithEvents lblRewriteVal As Label
End Class
