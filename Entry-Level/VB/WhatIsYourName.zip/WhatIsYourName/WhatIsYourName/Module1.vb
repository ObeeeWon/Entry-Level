﻿Module Module1

    Sub Main()
        Console.WriteLine("Please enter your name: ")
        Dim name = Console.ReadLine
        Dim currDate = DateTime.Now
        Console.WriteLine($"Hello, {name}, on {currDate:d} at {currDate:t}")
        Console.Write("Press any Key to Terminate Program...")
        Console.ReadKey()



    End Sub

End Module
