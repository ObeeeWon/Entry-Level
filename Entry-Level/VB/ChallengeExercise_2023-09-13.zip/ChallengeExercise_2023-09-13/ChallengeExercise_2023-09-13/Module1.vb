﻿Module Module1

    Sub Main()
        Dim num1 As Integer
        Dim num2 As Integer
        Dim num3 As Integer
        Dim result As Short


        Console.Write("Please enter number one: ")
        num1 = Console.ReadLine()

        Console.Write("Please enter number two: ")
        num2 = Console.ReadLine()

        Console.Write("Please type number three: ")
        num3 = Console.ReadLine()

        result = (num1 + num2 + num3) / 3

        Console.Write($"The Average of Number 1 and Number 2 and Number 3 is " & result)

        Console.ReadKey()

    End Sub

End Module
