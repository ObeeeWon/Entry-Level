﻿'----------------------------------------------------------------------------
'Program Info
'----------------------------------------------------------------------------
'Program: Loan Interest Calculator
'Date: 10-13-2023
'Author: Xiangyu Feng
'Operation: Design a console application that will calculate the total cost
'           of a loan as well as the interest porttion of the loan based on
'           information supplied by the user.
'           -----------------------------------------------------------------
'           Formulas:
'           Total Loan Cost = (((r * P)/(1-(1+r)^-N) * N)
'           r = Monthly Interest Rate (Yearly Interest Rate / 100 /12)
'           P = Principal Amount On the Loan
'           N = Total # Of Months For the Loan
'
'           Monthly Rate = YearlyRate/100/12
'
'-----------------------------------------------------------------------------
'Change Log
'-----------------------------------------------------------------------------
'Date                  Programmer                 Change
'-----------------------------------------------------------------------------
'13-10-2023            Xiangyu Feng               First Build
'14-10-2023            Xiangyu Feng               Improve Comments Readability

Module Module1

    Sub Main()
        'Define Variables: Total loan cost, yearly rate, montyly rate, principal amount and loan months.
        Dim dec_LoanAmount As Decimal
        Dim dec_RateYearly As Decimal
        Dim dec_RateMonthly As Decimal
        Dim dec_PrincipalAmount As Decimal
        Dim uint_Months As UInt32
        Dim dec_TotalInterest As Decimal

        'Capture Loan Amount
        Console.WriteLine("Enter The Loan Amount:")
        dec_PrincipalAmount = Console.ReadLine()

        'Capture Yearly Rate
        Console.WriteLine("Enter The Annual Interest Rate:")
        dec_RateYearly = Console.ReadLine()

        'Capture Loan Months
        Console.WriteLine("Enter The Loan Period In Months:")
        uint_Months = Console.ReadLine()

        'Calculate Monthly Rate
        dec_RateMonthly = dec_RateYearly / 100 / 12

        'Calculate Total Loan Cost
        dec_LoanAmount = Math.Round(((dec_RateMonthly * dec_PrincipalAmount) / (1 - (1 + dec_RateMonthly) ^ -uint_Months) * uint_Months), 2)

        'Calculate Loan Interest
        dec_TotalInterest = dec_LoanAmount - dec_PrincipalAmount

        'Output Loan Amount
        Console.WriteLine()
        Console.WriteLine("Details:")
        Console.WriteLine("Loan Amount")
        Console.WriteLine("-----------")
        Console.WriteLine("$" & dec_PrincipalAmount)

        'Output Yearly Rate
        Console.WriteLine()
        Console.WriteLine("Interest Rate")
        Console.WriteLine("-----------")
        Console.WriteLine(dec_RateYearly & "%")

        'Output Loan Months
        Console.WriteLine()
        Console.WriteLine("Number of Months")
        Console.WriteLine("-----------")
        Console.WriteLine(uint_Months)

        'Output Total Loan Cost
        Console.WriteLine()
        Console.WriteLine("Total Cost of Loan: $" & dec_LoanAmount)

        'Output Loan Interest
        Console.WriteLine()
        Console.WriteLine("Total Interest: $" & dec_TotalInterest)
        Console.WriteLine()

        'Capture Key Stroke to Terminate Program
        Console.WriteLine("==== May The Force Be with You ====")
        Console.WriteLine("Press Any Key to Terminate Program.")
        Console.ReadKey()

    End Sub

End Module
