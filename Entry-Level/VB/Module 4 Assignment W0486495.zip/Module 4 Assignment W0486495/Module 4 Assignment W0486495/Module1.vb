﻿'----------------------------------------------------------------------------
'Program Info
'----------------------------------------------------------------------------
'Program:Nelly’s Netflix Store
'Date:05-11-2023
'Author:Xiangyu Feng
'Operation: Nelly is a reseller of streaming services for Netflix. Packages
'are sold on a Monthly basis (paid in full) with the exception of the annual
'Premium package available which Is only sold For 1 year. 
'
'-----------------------------------------------------------------------------
'Change Log
'-----------------------------------------------------------------------------
'Date                 Programmer                Change
'-----------------------------------------------------------------------------
'05-11-2023           Xiangyu Feng             First Build
'08-11-2023           Xiangyu Feng             Fixed:Invalid input cause Crush

Module Module1
    'Use Constant to store fixed data.
    Const PriceBasicAdsMon As Decimal = 5.99
    Const PriceBasicMon As Decimal = 9.99
    Const PriceStandardMon As Decimal = 16.49
    Const PricePremiumMon As Decimal = 20.99
    Const PricePremiumAnnual As Decimal = 249.99
    Const DiscountPercentage As Decimal = 0.2
    Const TaxRate As Decimal = 0.15
    Const ForFreeMonthsCalc As UInt16 = 2

    'Use Dim for number storage and calculation result.
    Dim PackageName As String
    Dim PackNumSelected As String
    Dim MonthsSelected As UInt16
    Dim MonthsFree As UInt16
    Dim MonthsTotal As UInt16
    Dim Subtotal As Decimal
    Dim ReceiptPrice As Decimal
    Dim MoneySaved As Decimal
    Dim Discount As Decimal
    Dim Tax As Decimal
    Dim Total As Decimal
    Dim ReceiptTime = Date.Now


    Sub Main()
        'List all package description and price information.
        PackageList()
        'Prpmpt question and store package number input from user.
        Console.WriteLine("Please Select a Package:")
        PackNumSelected = Console.ReadLine()
        'Prompts and Calculation depend on user's choice.
        Select Case PackNumSelected
            'Calculate & prompt Basic monthly package receipt.
            Case 1, 2
                BasicPackage()
            'Calculate & prompt Standard & Premium monthly package receipt.
            Case 3, 4
                StandAndPremPack()
            'Calculate & prompt Yearly package receipt.
            Case 5
                YearlyPackage()
            Case Else
                Console.WriteLine("Next Time Please Select Valid Number and Press Enter : )")
        End Select

        'Quit the Console
        Console.WriteLine()
        Console.WriteLine("Press Any Key to Quit.")
        Console.ReadKey()

    End Sub

    Sub PackageList()
        Console.WriteLine("======================")
        Console.WriteLine("Nelly's Netflix Store")
        Console.WriteLine("======================")
        Console.WriteLine("1 - Netflix Basic With Ads (Monthly) $5.99")
        Console.WriteLine("2 - Netflix Basic (Monthly) $9.99 ")
        Console.WriteLine("3 - Netflix Standard (Monthly) $16.49")
        Console.WriteLine("4 - Netflix Premium (Monthly) $20.99")
        Console.WriteLine("5 - Netflix Premium (Annual) $249.99")
        Console.WriteLine()
    End Sub
    Sub BasicPackage()
        Console.WriteLine("How many Months would you like to purchase:")
        MonthsSelected = Console.ReadLine()
        'Calculate basic monthly with ads & basic monthly
        Select Case PackNumSelected
            Case 1
                PackageName = "Netflix Basic With Ads (Monthly)"
                Subtotal = PriceBasicAdsMon * MonthsSelected
                ReceiptPrice = PriceBasicAdsMon
            Case 2
                PackageName = "Netflix Basic (Monthly)"
                Subtotal = PriceBasicMon * MonthsSelected
                ReceiptPrice = PriceBasicMon
        End Select
        'No saving for basic package
        MonthsTotal = MonthsSelected
        MonthsFree = 0
        MoneySaved = 0
        'Calculate basic price
        Tax = Math.Round((Subtotal * TaxRate), 2)
        Total = Subtotal + Tax
        'Prompt basic receipt
        MonthlyReceipt()
    End Sub

    Sub StandAndPremPack()
        Console.WriteLine("How many Months would you like to purchase:")
        MonthsSelected = Console.ReadLine()
        'Calculate free months and saved money
        MonthsFree = (MonthsSelected / 6) * 2
        MonthsTotal = MonthsSelected + MonthsFree
        'Calculate standard monthly & premium monthly
        Select Case PackNumSelected
            Case 3
                PackageName = "Netflix Stabdard (Monthly)"
                Subtotal = PriceStandardMon * MonthsSelected
                MoneySaved = PriceStandardMon * MonthsFree
                ReceiptPrice = PriceStandardMon
            Case 4
                PackageName = "Netflix Premium (Monthly)"
                Subtotal = PricePremiumMon * MonthsSelected
                MoneySaved = PricePremiumMon * MonthsFree
                ReceiptPrice = PricePremiumMon
        End Select
        'Calculate basic and monthly premium price
        Tax = Math.Round((Subtotal * TaxRate), 2)
        Total = Subtotal + Tax
        MonthlyReceipt()
    End Sub

    Sub MonthlyReceipt()
        Console.WriteLine()
        Console.WriteLine("Invoice Summary:")
        Console.WriteLine("----------------------")
        Console.WriteLine($"Package Purchased: {PackageName}")
        Console.WriteLine($"Price: ${ReceiptPrice}")
        Console.WriteLine($"Months Purchased: {MonthsSelected}")
        Console.WriteLine($"You get {MonthsFree} months for free!")
        Console.WriteLine($"Total Months of Service {MonthsTotal}")
        Console.WriteLine($"You Saved: ${MoneySaved}")
        Console.WriteLine($"Subtotal: ${Subtotal}")
        Console.WriteLine($"Tax: ${Tax}")
        Console.WriteLine($"Total: ${Total}")
        Console.WriteLine($"Date: {ReceiptTime}")
    End Sub
    Sub YearlyPackage()
        PackageName = "Netflix Premium (Annual)"
        Discount = Math.Round((PricePremiumAnnual * DiscountPercentage), 2)
        Subtotal = PricePremiumAnnual - Discount
        Tax = Math.Round((Subtotal * TaxRate), 2)
        Total = Subtotal + Tax
        Console.WriteLine()
        Console.WriteLine("Invoice Summary:")
        Console.WriteLine("----------------------")
        Console.WriteLine($"Package Purchased: {PackageName}")
        Console.WriteLine($"Price: ${PricePremiumAnnual}")
        Console.WriteLine($"Discount: ${Discount}")
        Console.WriteLine($"Subtotal: ${Subtotal}")
        Console.WriteLine($"Tax: ${Tax}")
        Console.WriteLine($"Total: ${Total}")
        Console.WriteLine($"Date: ${ReceiptTime}")
    End Sub

End Module
