﻿Module Module1

    Sub Main()
        Dim num1 As Integer
        Dim num2 As Integer
        Dim answer As Integer

        Console.Write("Type a Number and press enter: ")
        num1 = Console.ReadLine()

        Console.Write("Please type another number to add to it: ")
        num2 = Console.ReadLine()

        answer = num1 + num2

        Console.WriteLine("The answer is " & answer)
        Console.Write("Press any Key to Quit...")
        Console.ReadKey()

    End Sub

End Module