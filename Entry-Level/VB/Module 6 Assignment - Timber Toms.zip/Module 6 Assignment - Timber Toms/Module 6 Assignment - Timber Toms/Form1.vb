﻿'----------------------------------------------------------------------------
'Program Info
'----------------------------------------------------------------------------
'Program:Timber Toms
'Date:1-12-2023
'Author:Xiangyu Feng
'Operation: a GUI program for Timber Tom’s Hardware that allows Tom to ring in a
'customer 's orders for the various products he sells.
'
'-----------------------------------------------------------------------------
'Change Log
'-----------------------------------------------------------------------------
'Date       Programmer     Change
'-----------------------------------------------------------------------------
'1-12-2023  Xiangyu Feng   First Build
'1-12-2023  Xiangyu Feng   Validation Upgrade


Public Class Form1
    Dim arr_ItemNum() As Int16 = {100, 101, 200, 201, 203, 305, 306}
    Dim arr_Desc() As String = {"Wrench", "Pipe wrench", "Rip saw", "Framing Hammer", "Framing square", "Solder(roll)", "Paste"}
    Dim arr_Price() As Decimal = {3.5, 5.75, 16.23, 32.5, 27.5, 6.34, 4.26}
    Dim arr_OrderedItems() As String
    Dim dec_ItemTotal As Decimal
    Dim dec_SubTotal As Decimal = 0
    Dim dec_Total As Decimal
    Dim Counter As Byte
    Dim Counter_2 As Byte
    Dim index As Int16
    Dim int_input As Int16
    Dim boolCounter As Boolean

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        For Counter = 0 To arr_ItemNum.Count - 1
            txtItemNum.Focus()
            'Validate Input: Not number at Item Number.
            If Not IsNumeric(txtItemNum.Text) Then
                MsgBox("Please Type a Number at Item Number.")
                txtItemNum.Clear()
                boolCounter = False
                Exit For
                'Validate Input: Item Number does not exist.
            ElseIf Not arr_ItemNum.Contains(txtItemNum.Text) Then
                MsgBox("Please Select an Existed Item Number.")
                txtItemNum.Clear()
                boolCounter = False
                Exit For
                'Validate Input: Not a Number at Quantity.
            ElseIf Not IsNumeric(txtQuantity.Text) Then
                MsgBox("Please Type a Number at Quantity.")
                txtQuantity.Clear()
                boolCounter = False
                Exit For
                'Validate Input: Not valid quantity.
            ElseIf txtQuantity.Text <= 0 Then
                MsgBox("Please Type a Number Greater than 0 at Quantity.")
                txtQuantity.Clear()
                boolCounter = False
                Exit For
                'Validate Input: Limit quantity range
            ElseIf txtQuantity.Text > 1000 Then
                MsgBox("Please Type a Number Smaller than 1000 at Quantity for Each Time.")
                txtQuantity.Clear()
                boolCounter = False
            Else
                boolCounter = True
            End If
        Next
        If boolCounter = True Then
            'Calculation and Items Storage
            'Find the index of the Item Number
            int_input = txtItemNum.Text
            index = Array.IndexOf(arr_ItemNum, int_input)
            'Calculate Item Total & Sub Total Price
            dec_ItemTotal = arr_Price(index) * txtQuantity.Text
            dec_SubTotal += dec_ItemTotal
            'Orgnize Ordered Items Array
            lb_Ordered.Items.Add($"{arr_ItemNum(index)}" & vbTab & $"{arr_Desc(index)}" & vbTab & vbTab & $"{txtQuantity.Text}" & vbTab & $"${arr_Price(index)}" & vbTab & $"${dec_ItemTotal}")
        End If
    End Sub
    'Prepare for transport Ordered Items to Invoice



    Private Sub btnComplete_Click(sender As Object, e As EventArgs) Handles btnComplete.Click
        lb_Invoice.Items.Clear()
        lb_Invoice.Items.Add("Timber Tom's Hardware")
        For Counter = 0 To lb_Ordered.Items.Count - 1
            'List Ordered Items to Invoice
            lb_Invoice.Items.Add(lb_Ordered.Items(Counter))
        Next
        lb_Invoice.Items.Add("Tax:$" & Math.Round(dec_SubTotal * 0.15, 2))
        lb_Invoice.Items.Add("Total:$" & Math.Round(dec_SubTotal * 0.15, 2) + dec_SubTotal)

    End Sub

    Private Sub lblClear_Click(sender As Object, e As EventArgs) Handles lblClear.Click
        txtItemNum.Clear()
        txtQuantity.Clear()
        lb_Ordered.Items.Clear()
        lb_Invoice.Items.Clear()
    End Sub

    Private Sub lblExit_Click(sender As Object, e As EventArgs) Handles lblExit.Click
        Me.Close()
    End Sub
End Class
