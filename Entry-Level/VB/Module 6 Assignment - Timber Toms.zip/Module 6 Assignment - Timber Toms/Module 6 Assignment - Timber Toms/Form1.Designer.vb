﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnComplete = New System.Windows.Forms.Button()
        Me.lblClear = New System.Windows.Forms.Button()
        Me.lblExit = New System.Windows.Forms.Button()
        Me.lb_Ordered = New System.Windows.Forms.ListBox()
        Me.lb_Invoice = New System.Windows.Forms.ListBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lblItemNum = New System.Windows.Forms.Label()
        Me.lblQuantity = New System.Windows.Forms.Label()
        Me.lblOrdered = New System.Windows.Forms.Label()
        Me.lblInvoice = New System.Windows.Forms.Label()
        Me.txtItemNum = New System.Windows.Forms.TextBox()
        Me.txtQuantity = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnComplete
        '
        Me.btnComplete.Location = New System.Drawing.Point(38, 408)
        Me.btnComplete.Name = "btnComplete"
        Me.btnComplete.Size = New System.Drawing.Size(122, 23)
        Me.btnComplete.TabIndex = 0
        Me.btnComplete.Text = "Complete Order"
        Me.btnComplete.UseVisualStyleBackColor = True
        '
        'lblClear
        '
        Me.lblClear.Location = New System.Drawing.Point(198, 408)
        Me.lblClear.Name = "lblClear"
        Me.lblClear.Size = New System.Drawing.Size(75, 23)
        Me.lblClear.TabIndex = 1
        Me.lblClear.Text = "Clear"
        Me.lblClear.UseVisualStyleBackColor = True
        '
        'lblExit
        '
        Me.lblExit.Location = New System.Drawing.Point(312, 408)
        Me.lblExit.Name = "lblExit"
        Me.lblExit.Size = New System.Drawing.Size(75, 23)
        Me.lblExit.TabIndex = 2
        Me.lblExit.Text = "Exit"
        Me.lblExit.UseVisualStyleBackColor = True
        '
        'lb_Ordered
        '
        Me.lb_Ordered.FormattingEnabled = True
        Me.lb_Ordered.ItemHeight = 12
        Me.lb_Ordered.Location = New System.Drawing.Point(36, 125)
        Me.lb_Ordered.Name = "lb_Ordered"
        Me.lb_Ordered.Size = New System.Drawing.Size(366, 112)
        Me.lb_Ordered.TabIndex = 3
        '
        'lb_Invoice
        '
        Me.lb_Invoice.FormattingEnabled = True
        Me.lb_Invoice.ItemHeight = 12
        Me.lb_Invoice.Location = New System.Drawing.Point(36, 264)
        Me.lb_Invoice.Name = "lb_Invoice"
        Me.lb_Invoice.Size = New System.Drawing.Size(366, 112)
        Me.lb_Invoice.TabIndex = 4
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(36, 74)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(113, 23)
        Me.btnAdd.TabIndex = 5
        Me.btnAdd.Text = "Add To Order"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lblItemNum
        '
        Me.lblItemNum.AutoSize = True
        Me.lblItemNum.Location = New System.Drawing.Point(36, 18)
        Me.lblItemNum.Name = "lblItemNum"
        Me.lblItemNum.Size = New System.Drawing.Size(71, 12)
        Me.lblItemNum.TabIndex = 6
        Me.lblItemNum.Text = "Item Number"
        '
        'lblQuantity
        '
        Me.lblQuantity.AutoSize = True
        Me.lblQuantity.Location = New System.Drawing.Point(171, 18)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(53, 12)
        Me.lblQuantity.TabIndex = 7
        Me.lblQuantity.Text = "Quantity"
        '
        'lblOrdered
        '
        Me.lblOrdered.AutoSize = True
        Me.lblOrdered.Location = New System.Drawing.Point(36, 107)
        Me.lblOrdered.Name = "lblOrdered"
        Me.lblOrdered.Size = New System.Drawing.Size(83, 12)
        Me.lblOrdered.TabIndex = 8
        Me.lblOrdered.Text = "Ordered Items"
        '
        'lblInvoice
        '
        Me.lblInvoice.AutoSize = True
        Me.lblInvoice.Location = New System.Drawing.Point(36, 245)
        Me.lblInvoice.Name = "lblInvoice"
        Me.lblInvoice.Size = New System.Drawing.Size(47, 12)
        Me.lblInvoice.TabIndex = 9
        Me.lblInvoice.Text = "Invoice"
        '
        'txtItemNum
        '
        Me.txtItemNum.Location = New System.Drawing.Point(36, 39)
        Me.txtItemNum.Name = "txtItemNum"
        Me.txtItemNum.Size = New System.Drawing.Size(100, 21)
        Me.txtItemNum.TabIndex = 10
        '
        'txtQuantity
        '
        Me.txtQuantity.Location = New System.Drawing.Point(173, 39)
        Me.txtQuantity.Name = "txtQuantity"
        Me.txtQuantity.Size = New System.Drawing.Size(100, 21)
        Me.txtQuantity.TabIndex = 11
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(495, 460)
        Me.Controls.Add(Me.txtQuantity)
        Me.Controls.Add(Me.txtItemNum)
        Me.Controls.Add(Me.lblInvoice)
        Me.Controls.Add(Me.lblOrdered)
        Me.Controls.Add(Me.lblQuantity)
        Me.Controls.Add(Me.lblItemNum)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.lb_Invoice)
        Me.Controls.Add(Me.lb_Ordered)
        Me.Controls.Add(Me.lblExit)
        Me.Controls.Add(Me.lblClear)
        Me.Controls.Add(Me.btnComplete)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnComplete As Button
    Friend WithEvents lblClear As Button
    Friend WithEvents lblExit As Button
    Friend WithEvents lb_Ordered As ListBox
    Friend WithEvents lb_Invoice As ListBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents lblItemNum As Label
    Friend WithEvents lblQuantity As Label
    Friend WithEvents lblOrdered As Label
    Friend WithEvents lblInvoice As Label
    Friend WithEvents txtItemNum As TextBox
    Friend WithEvents txtQuantity As TextBox
End Class
